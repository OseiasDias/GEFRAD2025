export default function Copyright() {

  return (<>
    <p className="text-center d-block text-white fundoFooter py-4 mb-0" >
      Copyright © <strong>2025</strong> <em>Anuncios Loc Admim</em>, Ltd. Todos os
      direitos reservados.
      <br />
      Desenvolvido por: <strong><a href="#" target="_blank">  FC-UAN(Estudantes 4º Ciências da Computação) Grupo nº8</a></strong>
    </p>
  </>
  )
}